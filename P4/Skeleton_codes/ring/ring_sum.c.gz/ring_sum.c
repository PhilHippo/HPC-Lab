#include <mpi.h> // MPI
#include <stdio.h>

int main(int argc, char *argv[]) {

  // Initialize MPI, get size and rank
  int size, rank;
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  // IMPLEMENT: Ring sum algorithm
  int sum = 0; // initialize sum to 0
  
  // Determine neighbors in ring topology
  int next = (rank + 1) % size;      // neighbor in increasing direction
  int prev = (rank - 1 + size) % size; // neighbor in decreasing direction
  
  int tag = 0;
  int send_val = rank; // value to send around the ring (start with own rank)
  
  // Perform n iterations (where n = size)
  for (int i = 0; i < size; i++) {
    int recv_val;
    
    // Alternate send/receive order based on even/odd rank to avoid deadlock
    if (rank % 2 == 0) {
      // Even ranks: Send first, then Receive
      MPI_Send(&send_val, 1, MPI_INT, next, tag, MPI_COMM_WORLD);
      MPI_Recv(&recv_val, 1, MPI_INT, prev, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    } else {
      // Odd ranks: Receive first, then Send
      MPI_Recv(&recv_val, 1, MPI_INT, prev, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      MPI_Send(&send_val, 1, MPI_INT, next, tag, MPI_COMM_WORLD);
    }
    
    // Accumulate received value to sum
    sum += recv_val;
    
    // Update send_val for next iteration (pass along what we received)
    send_val = recv_val;
  }

  printf("Process %i: Sum = %i\n", rank, sum);

  // Finalize MPI
  MPI_Finalize();

  return 0;
}