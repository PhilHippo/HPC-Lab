#!/usr/bin/env python3
import csv
import os
from typing import List, Tuple, Dict

import matplotlib.pyplot as plt


DATA_DIR = os.path.dirname(os.path.abspath(__file__))

FILES = {
    "strong_single": "strong_scaling_data_single.csv",
    "strong_multi": "strong_scaling_data_multi.csv",
    "weak_single": "weak_scaling_data_single.csv",
    "weak_multi": "weak_scaling_data_multi.csv",
}


def read_scaling_csv(path: str) -> Tuple[List[int], List[float]]:
    ps: List[int] = []
    times: List[float] = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Expected columns: p,n,iter,theta,time
            p = int(row["p"])
            t = float(row["time"])
            ps.append(p)
            times.append(t)
    return ps, times


def main() -> None:
    strong_speedups: Dict[str, Tuple[List[int], List[float]]] = {}
    weak_efficiencies: Dict[str, Tuple[List[int], List[float]]] = {}
    strong_all_y: List[float] = []
    weak_all_y: List[float] = []
    for key, filename in FILES.items():
        path = os.path.join(DATA_DIR, filename)
        if not os.path.exists(path):
            raise FileNotFoundError(f"Missing CSV file: {path}")
        p_list, time_list = read_scaling_csv(path)
        t1 = time_list[0]
        if key.startswith("strong_"):
            speedup = [t1 / t for t in time_list]
            strong_speedups[key] = (p_list, speedup)
            strong_all_y.extend(speedup)
        else:
            efficiency = [t1 / t for t in time_list]
            weak_efficiencies[key] = (p_list, efficiency)
            weak_all_y.extend(efficiency)

    if not strong_all_y or not weak_all_y:
        raise RuntimeError("Missing data to plot.")

    strong_y_min = max(1e-2, min(strong_all_y))
    strong_y_max = max(strong_all_y)
    strong_y_lim = (strong_y_min, strong_y_max * 1.1)

    weak_y_min = 0.0
    weak_y_max = max(1.0, max(weak_all_y))
    weak_y_lim = (weak_y_min, min(1.2, weak_y_max * 1.05))

    if "strong_single" in strong_speedups and "strong_multi" in strong_speedups:
        p_single, sp_single = strong_speedups["strong_single"]
        p_multi, sp_multi = strong_speedups["strong_multi"]
        x_ticks = sorted(set(p_single) | set(p_multi))
        plt.figure(figsize=(7.5, 5))
        plt.plot(p_single, sp_single, marker="o", linestyle="-", color="#1f77b4", label="Single node")
        plt.plot(p_multi, sp_multi, marker="s", linestyle="-", color="#d62728", label="Multi node")
        plt.plot(x_ticks, x_ticks, linestyle="--", color="black", label="Ideal")
        plt.title("Strong scaling - Speedup (single vs multi)")
        plt.xlabel("Processes (p)")
        plt.ylabel("Speedup")
        try:
            plt.xscale("log", base=2)
            plt.yscale("log", base=2)
        except TypeError:
            plt.xscale("log", basex=2)
            plt.yscale("log", basey=2)
        plt.ylim(*strong_y_lim)
        plt.xticks(x_ticks, x_ticks)
        plt.grid(True, which="both", linestyle="--", alpha=0.4)
        plt.legend()
        out_path = os.path.join(DATA_DIR, "strong.png")
        plt.tight_layout()
        plt.savefig(out_path, dpi=150)
        plt.close()

    if "weak_single" in weak_efficiencies and "weak_multi" in weak_efficiencies:
        p_single, ef_single = weak_efficiencies["weak_single"]
        p_multi, ef_multi = weak_efficiencies["weak_multi"]
        x_ticks = sorted(set(p_single) | set(p_multi))
        plt.figure(figsize=(7.5, 5))
        plt.plot(p_single, ef_single, marker="o", linestyle="-", color="#1f77b4", label="Single node")
        plt.plot(p_multi, ef_multi, marker="s", linestyle="-", color="#d62728", label="Multi node")
        plt.axhline(1.0, linestyle="--", color="black", label="Ideal")
        plt.title("Weak scaling - Efficiency (single vs multi)")
        plt.xlabel("Processes (p)")
        plt.ylabel("Efficiency (T1/Tp)")
        try:
            plt.xscale("log", base=2)
        except TypeError:
            plt.xscale("log", basex=2)
        plt.ylim(*weak_y_lim)
        plt.xticks(x_ticks, x_ticks)
        plt.grid(True, which="both", linestyle="--", alpha=0.4)
        plt.legend()
        out_path = os.path.join(DATA_DIR, "weak.png")
        plt.tight_layout()
        plt.savefig(out_path, dpi=150)
        plt.close()

if __name__ == "__main__":
    main()


