#!/bin/bash
#SBATCH --job-name=strong_single
#SBATCH --output=strong_single_%j.out
#SBATCH --error=strong_single_%j.err
#SBATCH --time=01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=20
#SBATCH --cpus-per-task=1
#SBATCH --exclusive

module load gcc openmpi
cd $SLURM_SUBMIT_DIR

# Compile the program
make clean
make

# Strong Scaling - Single Node
# p = 1, 2, 4, 8, 16, 20
# n = 10000
# niter = 300
# tol = -1e-6
# All processes on one node

TEST_CASE=3
N=10000
NITER=300
TOL=-1e-6

echo "Strong Scaling Single Node"
echo "p,n,iter,theta,time"

for p in 1 2 4 8 16 20; do
    # echo "Running with p=$p"
    srun -n $p ./powermethod_rows $TEST_CASE $N $NITER $TOL
done
