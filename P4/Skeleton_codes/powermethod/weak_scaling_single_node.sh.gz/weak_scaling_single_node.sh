#!/bin/bash
#SBATCH --job-name=weak_single
#SBATCH --output=weak_single_%j.out
#SBATCH --error=weak_single_%j.err
#SBATCH --time=01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=20
#SBATCH --cpus-per-task=1
#SBATCH --exclusive

module load gcc openmpi
cd $SLURM_SUBMIT_DIR

# Compile the program
make clean
make

# Weak Scaling - Single Node
# p = 1, 2, 4, 8, 16, 20
# n = 10000 * sqrt(p)
# niter = 300
# tol = -1e-6
# All processes on one node

TEST_CASE=3
BASE_N=10000
NITER=300
TOL=-1e-6

echo "Weak Scaling Single Node"
echo "p,n,iter,theta,time"

for p in 1 2 4 8 16 20; do
    # Calculate n = 10000 * sqrt(p)
    N=$(awk -v p=$p -v base=$BASE_N 'BEGIN { printf "%.0f", base * sqrt(p) }')
    
    # echo "Running with p=$p, n=$N"
    srun -n $p ./powermethod_rows $TEST_CASE $N $NITER $TOL
done
