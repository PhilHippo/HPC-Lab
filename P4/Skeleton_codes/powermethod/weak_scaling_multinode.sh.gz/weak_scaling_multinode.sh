#!/bin/bash
#SBATCH --job-name=weak_multi
#SBATCH --output=weak_multi_%j.out
#SBATCH --error=weak_multi_%j.err
#SBATCH --time=01:00:00
#SBATCH --nodes=16
#SBATCH --ntasks=16
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=1
#SBATCH --exclusive

module load gcc openmpi
cd $SLURM_SUBMIT_DIR

# Compile the program
make clean
make

# Weak Scaling - Multi Node
# p = 1, 2, 4, 8, 16
# n = 10000 * sqrt(p)
# niter = 300
# tol = -1e-6
# 1 process per node

TEST_CASE=3
BASE_N=10000
NITER=300
TOL=-1e-6

echo "Weak Scaling Multi Node"
echo "p,n,iter,theta,time"

for p in 1 2 4 8 16; do
    # Calculate n = 10000 * sqrt(p)
    N=$(awk -v p=$p -v base=$BASE_N 'BEGIN { printf "%.0f", base * sqrt(p) }')
    
    # echo "Running with p=$p, n=$N"
    # Use --map-by ppr:1:node to ensure 1 process per node
    srun -n $p --ntasks-per-node=1 ./powermethod_rows $TEST_CASE $N $NITER $TOL
done
