/****************************************************************
 *                                                              *
 * This file has been written as a sample solution to an        *
 * exercise in a course given at the CSCS-USI Summer School     *
 * It is made freely available with the understanding that      *
 * every copy of this file must include this header and that    *
 * CSCS/USI take no responsibility for the use of the enclosed  *
 * teaching material.                                           *
 *                                                              *
 * Purpose: Exchange ghost cell in all 8 directions             *
 *                                                              *
 * Contents: C-Source                                           *
 *                                                              *
 ****************************************************************/

 #include <stdio.h>
 #include <stdlib.h>
 #include <mpi.h>
 
 #define SUBDOMAIN 6
 #define DOMAINSIZE (SUBDOMAIN+2)
 
 int main(int argc, char *argv[])
 {
     int rank, size, i, j, dims[2], periods[2];
     int rank_top, rank_bottom, rank_left, rank_right;
     int rank_ne, rank_nw, rank_se, rank_sw;
     int coords[2], neighbor_coords[2];
     double data[DOMAINSIZE*DOMAINSIZE];
     MPI_Request request[16];
     MPI_Status status[16];
     MPI_Comm comm_cart;
     MPI_Datatype data_ghost;
 
     // Initialize MPI
     MPI_Init(&argc, &argv);
 
     MPI_Comm_rank(MPI_COMM_WORLD, &rank);
     MPI_Comm_size(MPI_COMM_WORLD, &size);
 
     if (size!=16) {
         printf("please run this with 16 processors\n");
         MPI_Finalize();
         exit(1);
     }
 
     // initialize the domain
     for (i=0; i<DOMAINSIZE*DOMAINSIZE; i++) {
         data[i]=rank;
     }
 
     // Set the dimensions of the processor grid and periodic boundaries
     dims[0] = 4;
     dims[1] = 4;
     periods[0] = 1;
     periods[1] = 1;
 
     // Create a Cartesian communicator (4*4) with periodic boundaries
     MPI_Cart_create(MPI_COMM_WORLD, 2, dims, periods, 0, &comm_cart);
 
     // Find cardinal direction neighbors
     MPI_Cart_shift(comm_cart, 0, 1, &rank_top, &rank_bottom);
     MPI_Cart_shift(comm_cart, 1, 1, &rank_left, &rank_right);
 
     // Find diagonal neighbors
     MPI_Cart_coords(comm_cart, rank, 2, coords);
     
     // Northeast
     neighbor_coords[0] = (coords[0] - 1 + dims[0]) % dims[0];
     neighbor_coords[1] = (coords[1] + 1) % dims[1];
     MPI_Cart_rank(comm_cart, neighbor_coords, &rank_ne);
     
     // Northwest
     neighbor_coords[0] = (coords[0] - 1 + dims[0]) % dims[0];
     neighbor_coords[1] = (coords[1] - 1 + dims[1]) % dims[1];
     MPI_Cart_rank(comm_cart, neighbor_coords, &rank_nw);
     
     // Southeast
     neighbor_coords[0] = (coords[0] + 1) % dims[0];
     neighbor_coords[1] = (coords[1] + 1) % dims[1];
     MPI_Cart_rank(comm_cart, neighbor_coords, &rank_se);
     
     // Southwest
     neighbor_coords[0] = (coords[0] + 1) % dims[0];
     neighbor_coords[1] = (coords[1] - 1 + dims[1]) % dims[1];
     MPI_Cart_rank(comm_cart, neighbor_coords, &rank_sw);
 
     // Create derived datatype for sending a column
     MPI_Type_vector(SUBDOMAIN, 1, DOMAINSIZE, MPI_DOUBLE, &data_ghost);
     MPI_Type_commit(&data_ghost);
 
     int req_count = 0;
 
     // Exchange with cardinal directions (top, bottom, left, right)
     
     // Top and bottom rows
     MPI_Irecv(&data[0*DOMAINSIZE + 1], SUBDOMAIN, MPI_DOUBLE, 
               rank_top, 0, comm_cart, &request[req_count++]);
     MPI_Irecv(&data[(SUBDOMAIN+1)*DOMAINSIZE + 1], SUBDOMAIN, MPI_DOUBLE, 
               rank_bottom, 1, comm_cart, &request[req_count++]);
     
     MPI_Send(&data[1*DOMAINSIZE + 1], SUBDOMAIN, MPI_DOUBLE, 
              rank_top, 1, comm_cart);
     MPI_Send(&data[SUBDOMAIN*DOMAINSIZE + 1], SUBDOMAIN, MPI_DOUBLE, 
              rank_bottom, 0, comm_cart);
 
     // Left and right columns
     MPI_Irecv(&data[1*DOMAINSIZE + 0], 1, data_ghost, 
               rank_left, 2, comm_cart, &request[req_count++]);
     MPI_Irecv(&data[1*DOMAINSIZE + (SUBDOMAIN+1)], 1, data_ghost, 
               rank_right, 3, comm_cart, &request[req_count++]);
     
     MPI_Send(&data[1*DOMAINSIZE + 1], 1, data_ghost, 
              rank_left, 3, comm_cart);
     MPI_Send(&data[1*DOMAINSIZE + SUBDOMAIN], 1, data_ghost, 
              rank_right, 2, comm_cart);
 
     // Wait for cardinal direction exchanges to complete
     MPI_Waitall(req_count, request, status);
     req_count = 0;
 
     // BONUS: Exchange corner ghost cells with diagonal neighbors
     
     // Northeast corner
     MPI_Irecv(&data[0*DOMAINSIZE + (SUBDOMAIN+1)], 1, MPI_DOUBLE, 
               rank_ne, 4, comm_cart, &request[req_count++]);
     MPI_Send(&data[1*DOMAINSIZE + SUBDOMAIN], 1, MPI_DOUBLE, 
              rank_ne, 7, comm_cart);
     
     // Northwest corner
     MPI_Irecv(&data[0*DOMAINSIZE + 0], 1, MPI_DOUBLE, 
               rank_nw, 5, comm_cart, &request[req_count++]);
     MPI_Send(&data[1*DOMAINSIZE + 1], 1, MPI_DOUBLE, 
              rank_nw, 6, comm_cart);
     
     // Southeast corner
     MPI_Irecv(&data[(SUBDOMAIN+1)*DOMAINSIZE + (SUBDOMAIN+1)], 1, MPI_DOUBLE, 
               rank_se, 6, comm_cart, &request[req_count++]);
     MPI_Send(&data[SUBDOMAIN*DOMAINSIZE + SUBDOMAIN], 1, MPI_DOUBLE, 
              rank_se, 5, comm_cart);
     
     // Southwest corner
     MPI_Irecv(&data[(SUBDOMAIN+1)*DOMAINSIZE + 0], 1, MPI_DOUBLE, 
               rank_sw, 7, comm_cart, &request[req_count++]);
     MPI_Send(&data[SUBDOMAIN*DOMAINSIZE + 1], 1, MPI_DOUBLE, 
              rank_sw, 4, comm_cart);
 
     // Wait for all diagonal exchanges to complete
     MPI_Waitall(req_count, request, status);
 
     if (rank==9) {
         printf("data of rank 9 after communication (with corners)\n");
         for (j=0; j<DOMAINSIZE; j++) {
             for (i=0; i<DOMAINSIZE; i++) {
                 printf("%4.1f ", data[i+j*DOMAINSIZE]);
             }
             printf("\n");
         }
     }
 
     // Free MPI resources
     MPI_Type_free(&data_ghost);
     MPI_Comm_free(&comm_cart);
 
     // Finalize MPI
     MPI_Finalize();
 
     return 0;
 }