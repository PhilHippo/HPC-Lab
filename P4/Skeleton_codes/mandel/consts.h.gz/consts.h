#ifndef CONSTS_H
#define CONSTS_H

// maximum number of iterations
#define MAX_ITERS 10000

// image size
#define IMAGE_WIDTH  4096
#define IMAGE_HEIGHT 4096

// the extent of the parameter plane ( MIN_X + iMIN_Y <= c < MAX_X + iMAX_Y )
#define MIN_X -2.1
#define MAX_X  0.7
#define MIN_Y -1.4
#define MAX_Y  1.4

typedef struct {
    long nx;     // Local  domain size in x-direction
    long ny;     // Local  domain size in y-direction
    long startx; // Global domain start index of local domain in x-direction
    long starty; // Global domain start index of local domain in y-direction
    long endx;   // Global domain end   index of local domain in x-direction
    long endy;   // Global domain end   index of local domain in y-direction
} Domain;

typedef struct {
    int x;         // x-coord. of current MPI process within the process grid
    int y;         // y-coord. of current MPI process within the process grid
    int nx;        // Number of processes in x-direction
    int ny;        // Number of processes in y-direction
    MPI_Comm comm; // (Cartesian) MPI communicator
} Partition;

/**
Create Partition structure that represents the layout of the grid of processes
organized in the Cartesian communicator (p.comm) that needs to be created
(MPI_Cart_create) and contains information such as number of processes in x and
y direction (p.nx, p.ny) and the coordinates of the current MPI process
(p.x, p.y).
*/
Partition createPartition(int mpi_rank, int mpi_size) {
    Partition p;

    // Determine size of the grid of MPI processes (p.nx, p.ny)
    int dims[2] = {0, 0};  // Let MPI_Dims_create choose the dimensions
    MPI_Dims_create(mpi_size, 2, dims);
    p.ny = dims[0];  // Number of processes in y-direction (rows)
    p.nx = dims[1];  // Number of processes in x-direction (columns)

    // Create cartesian communicator (p.comm)
    // We do not allow the reordering of ranks here
    int periods[2] = {0, 0};  // Non-periodic boundaries
    int reorder = 0;           // Do not reorder ranks
    MPI_Cart_create(MPI_COMM_WORLD, 2, dims, periods, reorder, &p.comm);
    
    // Determine the coordinates in the Cartesian grid (p.x, p.y)
    int coords[2];
    MPI_Cart_coords(p.comm, mpi_rank, 2, coords);
    p.y = coords[0];  // y-coordinate (row)
    p.x = coords[1];  // x-coordinate (column)

    return p;
}

/**
Updates Partition structure to represent the process mpi_rank.
Copy the grid information (p.nx, p.ny and p.comm) and update
the coordinates to represent position in the grid of the given
process (mpi_rank)
*/
Partition updatePartition(Partition p_old, int mpi_rank) {
    Partition p;

    // copy grid dimension and the communicator
    p.ny = p_old.ny;
    p.nx = p_old.nx;
    p.comm = p_old.comm;
    
    // Update the coordinates in the cartesian grid (p.x, p.y) for given mpi_rank
    int coords[2];
    MPI_Cart_coords(p.comm, mpi_rank, 2, coords);
    p.y = coords[0];  // y-coordinate (row)
    p.x = coords[1];  // x-coordinate (column)

    return p;
}

/**
Create Domain structure that represents the information about the local domain
of the current MPI process. It holds information such as the size of the local
domain (number of pixels in each dimension - d.nx, d.ny) and its global indices
(index of the first and the last pixel in the full image of the Mandelbrot set
that will be computed by the current process d.startx, d.endx and d.starty,
d.endy).
*/
Domain createDomain(Partition p) {
    Domain d;
    
    // Compute size of the local domain
    // Divide the image among processes, distributing remainder pixels evenly
    long base_nx = IMAGE_WIDTH / p.nx;
    long base_ny = IMAGE_HEIGHT / p.ny;
    long remainder_x = IMAGE_WIDTH % p.nx;
    long remainder_y = IMAGE_HEIGHT % p.ny;
    
    // Distribute remainder: first 'remainder' processes get one extra pixel
    d.nx = base_nx + (p.x < remainder_x ? 1 : 0);
    d.ny = base_ny + (p.y < remainder_y ? 1 : 0);

    // Compute index of the first pixel in the local domain
    // Sum widths of all previous processes
    d.startx = p.x * base_nx + (p.x < remainder_x ? p.x : remainder_x);
    d.starty = p.y * base_ny + (p.y < remainder_y ? p.y : remainder_y);

    // Compute index of the last pixel in the local domain
    d.endx = d.startx + d.nx - 1;
    d.endy = d.starty + d.ny - 1;

    return d;
}


#endif /* CONSTS_H */